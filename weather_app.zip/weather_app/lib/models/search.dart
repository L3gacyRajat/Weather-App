import 'package:flutter/material.dart';

class Search extends StatelessWidget {
  Search({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  final namecontroller = TextEditingController();
  final numcontroller =  TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Contact"),
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            Text('Search'),
            TextFormField(
              controller: namecontroller,
              validator: (value){
                if (value==null || value.isEmpty) {
                  return 'Please Enter Some text';
                }
                return null;
              },
              maxLength: 15,
            ),
            ElevatedButton(onPressed: () {
              if (_formKey.currentState!.validate())
              {
                //  namecontroller.clear();
                //   numcontroller.clear();
                Navigator.pop(context);
                /*   ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Processing Data'),
               backgroundColor: Colors.red.withOpacity(0.8),
               ),
              ); */
              }
            },
                child: Text("Search")
            ),
          ],
        ),
      ),
    );
  }
}