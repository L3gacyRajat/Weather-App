import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class WeatherLocation {
   String city;
   String temperature='';
   String wind='';
   String type='';
   String humidity='';

   WeatherLocation({
      required this.city,
   });

   Future<void> getData() async
   { try{
      var apikey = '48888cd8a7a93f826963ea8d2f2c329d';
      Response response = await get(Uri.parse(
          'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=48888cd8a7a93f826963ea8d2f2c329d'));
      Map data = jsonDecode(response.body);

      // temp,humidity
      Map temp_data = data['main'];
      double gettemp = temp_data['temp']-273;
      String getHumidity = temp_data['humidity'].toString();

      //weather type
      List weather_type = data['weather'];
      Map weather_type_data = weather_type[0];
      String gettype = weather_type_data['main'];

      //wind
      Map wind_data = data['wind'];
      double getwind = wind_data['speed'] * 3.6;

      temperature = gettemp.toString();
      humidity = getHumidity;
      wind = getwind.toString();
      type = gettype;
   }catch(e)
      {
         temperature = "NA";
         humidity = "NA";
         wind = "NA";
         type = "NA";
      }

   }


}
